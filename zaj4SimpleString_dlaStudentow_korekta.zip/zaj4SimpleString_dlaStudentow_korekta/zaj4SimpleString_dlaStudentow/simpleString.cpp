#include <iostream>
#include <algorithm>
#include <cstring>
#include <cctype>


using namespace std;

#include "simpleString.h"

#ifndef _MSC_FULL_VER // if not Visual Studio Compiler
    #warning "Klasa jest do zaimplementowania. Instrukcja w pliku naglowkowym"
#else

#endif

size_t SimpleString::instances_ = 0;


const char* SimpleString::data() {

    return this->data_;
}

size_t SimpleString::size() const {
    return this->size_;
}

size_t SimpleString::capacity() const {
    return this->capacity_;
}

const char *SimpleString::c_str() const {
    return this->data_;
}

SimpleString::SimpleString():data_(new char[1] {'\0'}), size_(0), capacity_(0) {
    instances_++;
}

SimpleString::SimpleString(const char *text):size_(strlen(text)), data_(new char[strlen(text) + 1]),capacity_(strlen(text)+1){
    strcpy(data_, text);
    instances_++;
}

SimpleString::SimpleString(const SimpleString &sample): data_(new char[strlen(sample.data_) + 1]), size_(sample.size_), capacity_(sample.capacity_) {
    memcpy(this->data_, sample.data_, sample.size_ + 1);
    instances_++;
}

SimpleString::~SimpleString() {
    delete[] this->data_;
    instances_--;
}

size_t SimpleString::instances() {
    return instances_;
}

void SimpleString::assign(const char *new_text) {
    delete[] this->data_;
    this->size_ = strlen(new_text);
    this->capacity_ = this->size_ + 1;
    data_ = new char[size_+1];
    strcpy(data_, new_text);

}

bool SimpleString::compare_char(char c1, char c2, bool case_sensitivity)const{
    if(c1 == c2 && case_sensitivity)
        return true;
    if(toupper(c1) == toupper(c2) && !case_sensitivity){
        return true;
    }
    return false;
}

bool SimpleString::equal_to(const SimpleString &second, bool case_sensitive)const{
    bool equality;
    if(this->size_ == second.size_){
        for(int i = 0; i < (int)size_; i++){
             equality = compare_char(this->data_[i], second.data_[i], case_sensitive);
            if(!equality)
                return false;
        }
        return true;
    }
}

SimpleString SimpleString::append(const SimpleString &second) {
    char *temp = new char[this->size_ + 1];
    temp = strcpy(temp, this->data_);
    this->size_ += second.size_;
    this->capacity_ += second.size_;

    this->data_ = new char[this->size_ + 1];

    this->data_ = strcpy(this->data_, temp);
    this->data_ = strcat(this->data_, second.data_);

    delete []temp;
    return this->data_;

}

