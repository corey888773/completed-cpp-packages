#include <iostream>
#include <algorithm> // std::sort, std::find, std::copy
#include <iterator> // std::distance, std::advance, std::back_inserter
#include <limits>   // std::numeric_limits<size_t>::max()
#include <numeric>  // std::accumulate()

using namespace std;

#include "containerWrapper.h"

#ifndef _MSC_FULL_VER // if not Visual Studio Compiler
    #warning "Klasa jest do zaimplementowania. Instrukcja w pliku naglowkowym"
#else
    #pragma message ("Klasa jest do zaimplementowania. Instrukcja w pliku naglowkowym")
#endif

VectorWrapper::VectorWrapper(const value_type elements[], size_t N){
    for(int i = 0; i < N; i++){
        this->impl_.push_back(elements[i]);
    }
}
void VectorWrapper::push_back(const value_type &element) {
    this->impl_.push_back(element);
}
void VectorWrapper::push_front(const value_type &element) {
    this->impl_.insert(this->impl_.begin(), element);
}
void VectorWrapper::insert(const IContainerWrapper::value_type &element, size_t position) {
  this->impl_.insert(impl_.begin() + position, element);
}
size_t VectorWrapper::size() const {
    return this->impl_.size();
}

void VectorWrapper::sort() {
    std::sort(this->impl_.begin(), this->impl_.end());
}

void VectorWrapper::erase(size_t position) {
    this->impl_.erase(this->impl_.begin() + position);
}

IContainerWrapper::value_type VectorWrapper::count() const {
    return accumulate(this->impl_.begin(),this->impl_.end(),value_type{});
}

size_t VectorWrapper::find(const IContainerWrapper::value_type &needle) const {

    for (size_t i = 0; i < this->impl_.size(); i++){
        if(this->impl_[i] == needle)
            return i;
    }
    return std::numeric_limits<size_t>::max();
}

IContainerWrapper::~IContainerWrapper() = default;


